# Cambios 0.25.0 (2026-10-09)

- Gráfico de retest con etiqueta, cantidad y barra en una misma fila; geometría responsiva y ampliación de texto verificables.
- Preparación con estados, contador y accesos directos; vista previa ajustada al ancho con zoom manual.
- Lectura YAML acelerada con prevalidación acotada, controles de grafo y fallback de compatibilidad.
- Recorrido PDF compacto por fases y conservación del texto introductorio junto al siguiente bloque.
- Fingerprint de claves públicas Ed25519, ciclo de vida POSIX sin servidor hijo y limpieza de señales de consola en Windows.
- CI ampliado y variable canónica de Chromium con compatibilidad del nombre anterior.
- Resultados, comandos y límites de esta versión en VALIDACION-0.25.0.md. Los registros de versiones anteriores conservan su alcance.

# Cambios 0.24.0 (2026-10-09)

- R10: firma Ed25519 separada y opcional para entregas, con clave pública externa, captura inmutable, verificación del ZIP/manifiesto exactos y rechazo de entradas ambiguas o no portables. Claves privadas locales fuera del editor; dependencia signing opcional.
- R12: serialización incremental de hallazgos y objetos compuestos del historial para proyectos grandes. No-op verificado sin escrituras ni cambio de ETag; YAML completo, activación atómica, recuperación y respaldos portátiles v1 conservados.
- Firma no equivale a cifrado, identidad real ni validación técnica. El historial local nuevo requiere 0.24.0; un respaldo exportado permite migrarlo a la versión anterior sin perder sus objetos.
- Comandos, medidas reales, auditoría completa y límites de esta ronda en VALIDACION-0.24.0.md. Ejemplos, capturas y documentos históricos conservados.

# Cambios 0.23.4 (2026-10-09)

- R11: catálogo explícito para errores propios y validación, elegido por el idioma de la interfaz antes de interpolar datos; idioma capturado para los trabajos y subprocesos de exportación. Sin sustituciones sobre texto del usuario ni cambios en códigos HTTP, CSRF, Origin/Host, revisiones o ETag.
- R14: recorrido vectorial por máquina en PDF desde fases, pasos y figuras registrados, con orden documental explícito, evidencia vinculada separada y alternativa textual paginable. Las flechas no acreditan causalidad, éxito ni verificación técnica. Los otros formatos conservan su contenido.
- Versiones históricas y ejemplos conservados. Comandos, pruebas y límites de esta ronda en VALIDACION-0.23.4.md.

# Cambios 0.23.3 (2026-10-09)

- R07: pestañas accesibles Evidencia y Decisiones por hallazgo, con vínculos y modelo existentes, galería compartida y borradores conservados.
- R08: comparación de solo lectura con snapshot de entrega identificado, selección explícita ante ambigüedad, guardas de revisión y comparación visual compartible o privada.
- R09: matriz y gráfico de retest derivados de observaciones reales, con filtros y distinción de estado, verificación técnica y resultado observado.
- La etapa delivered significa entrega registrada localmente, sin acreditar recepción del cliente ni éxito de exportación. Eliminar un hallazgo no acredita corrección.
- Sin cambio del esquema de proyectos ni de las políticas de publicación y exportación. Evidencia y límites en VALIDACION-0.23.3.md.

# Cambios 0.23.2 (2026-10-09)

- R03: atajos contextuales j/k, Ctrl+Enter/⌘+Enter y ayuda ?, con guardas de guardado, proyecto, revisión, foco y diálogos.
- R04: contexto de activos, responsable, estado y evidencias en fichas y tabla, a partir de las referencias reales; relaciones ausentes se indican explícitamente.
- R05: revisión agrupada, progreso de avisos de sesión y Guardar y comprobar siguiente. Resolver un aviso editorial no registra verificación técnica.
- R06: lista de preparación de entrega de solo lectura para anexos, posibles secretos y asociaciones, derivada de la revisión guardada y marcada como antigua cuando cambia el borrador.
- La importación y restauración preparan sus copias privadas sin una segunda transacción interna. Se corrige un defecto heredado: un fallo transitorio de limpieza podía dejar un registro que posteriormente recreaba una carpeta temporal y bloqueaba el respaldo del espacio. Se conservan la publicación atómica, los snapshots y la recuperación del proyecto.
- La navegación de teclado resuelve el UID del hallazgo visible tras una reordenación; los recursos corruptos o ausentes producen una comprobación pendiente en Entregar.
- No cambia el esquema de proyectos, los exportadores ni los documentos históricos. Se conservan revisión, recuperación y control de concurrencia.
- Evidencia y límites de esta ejecución en VALIDACION-0.23.2.md. Sin despliegue ni tag.

# Cambios 0.23.1 (2026-10-08)

- Anterior/Siguiente dentro del editor de hallazgo, con foco accesible y orden completo explícito del proyecto; selección por UID, sin reescribir fuentes al navegar.
- Preview sincronizada tras load con el mapa UID del snapshot renderizado; una respuesta antigua no reclama el proyecto actual y el resaltado no se exporta.
- Se comprueba visibilidad real del panel antes de pedir previews, incluidas vistas de inicio, tabla y móvil.
- Marca WebP lossless a 900×600, suficiente para el mayor uso a DPR3; transparencia conservada y PNG reducido retenido por documentación histórica.
- Navegación superior, relaciones de activos, calculadora CVSS y acciones de galería redistribuidas en móvil con texto ampliado al 200 %, sin etiquetas superpuestas, desbordamiento de página ni regiones vacías con scroll.
- Selector de versión CVSS con nombre accesible en español e inglés y etiqueta crítica con contraste AA en tema claro.
- Metadatos DOCX tomados de la copia preparada del informe: título, evaluador e idioma; sin autor de biblioteca, comentarios de plantilla ni fechas heredadas de 2013. Las fechas de creación desconocidas se omiten.
- Instrucciones de actualización ES/EN alineadas con 0.23.1; referencias históricas conservadas.
- Contrato de descarga progresiva del HTML sin carreras de temporizador: el servidor espera a comprobar controles aún sin cablear antes de liberar el resto, conservando las guardas de CLS, visibilidad y CSP.
- Contratos reales de navegador, negativos y límites documentados en VALIDACION-0.23.1.md.

# Cambios 0.23.0 (2026-10-08)

- Espacio opcional Evidencia y decisiones: mapa basado en vínculos existentes, afirmaciones observadas/inferidas/hipotéticas y límites explícitos de evidencia.
- Priorización empresarial redactada por el autor: servicio, objetivo, consecuencia, tolerancia, fuente, supuestos, razón y responsable; no se calcula pérdida financiera desde CVSS.
- Observaciones por campo y revisión ligada al contenido y a los comentarios. Una modificación invalida la aceptación previa; identidades declaradas localmente.
- Entregas técnica, ejecutiva y pública como archivos independientes. La pública usa texto aprobado explícito, alias y consentimiento; el modelo privado de revisión queda fuera de todos los informes.
- Revisión visual del PDF real, con miniaturas aisladas, notas por página y registro descargable ligado al SHA-256. Es opcional, temporal y no certifica Word nativo.
- Sustituciones literales con límites UTF-8 acumulados e intermedios, comprobados antes de reservar memoria; rechazo controlado de expansión excesiva.
- Reglas editoriales transparentes y adaptador Ollama opcional: solo campos seleccionados, modelos locales instalados, comparación antes de aceptación y guardas de revisión.
- Galería, tablero y lateral paginados para proyectos grandes. La vista previa oculta deja de renderizar y leer un editor heredado no añade campos al proyecto.
- Contratos, resultados medidos y límites en VALIDACION-0.23.0.md.

# Cambios 0.22.1 (2026-10-08)

- Los enlaces de los diálogos de trabajo usan el acento del tema y conservan el subrayado: el enlace GitHub de Acerca de ya no hereda el azul oscuro del navegador.

- El registro de cambios incorpora la entrada de 0.22.0, antes documentada únicamente en los README y su validación. Se conserva el registro histórico de aquella entrega.
- La cabecera usa desde el inicio el símbolo SVG que ya empleaba tras la inicialización; evita solicitar el logotipo completo durante ese arranque. El PNG permanece en bienvenida, Acerca de y documentación.
- El PNG de marca se recomprime sin cambiar sus píxeles RGBA ni sus dimensiones de 1536 × 1024: pasa de 1.602.203 a 1.483.406 bytes. Comprobaciones de esta revisión en VALIDACION-0.22.1.md.

# Cambios 0.22.0 (2026-10-08)

- Guía visual opcional de seis pasos en español e inglés: inicio, alcance, hallazgos, evidencia, revisión y entrega/respaldo. Se abre desde Inicio, el lateral o Más en móvil, con ejemplos ficticios y enlaces a las pantallas reales.
- Leer la guía no crea proyectos ni rellena campos. Su animación breve respeta movimiento reducido; al cambiar de paso, el foco revela el título si queda fuera de pantalla.
- El tablero de Hallazgos ofrece acciones visibles para añadir una entrada o usar la biblioteca, también cuando todavía está vacío.
- Abrir editores Markdown y opciones de inclusión conserva los datos y la revisión; los campos ausentes solo se incorporan al editar.
- Revisión y entrega comparten un preflight. Los avisos de validación y del flujo se conservan en verificacion.json y LEEME.txt, y requieren confirmación al entregar directamente o en cola. Los errores siguen bloqueando la entrega y la publicación usa el documento revisado.
- Los README priorizan instalación, primer uso y actualización. Contratos ejecutados, exportación de los cuatro formatos y límites en VALIDACION-0.22.0.md.

# Cambios 0.21.9 (2026-10-08)

- La exportación rechaza destinos que coinciden con la fuente o recursos locales referenciados, incluidos symlinks y hardlinks, antes de escribir. Se conserva la sustitución legítima de informes previos.
- La CLI protege también sus salidas secundarias y comprueba los destinos efectivos de Markdown.
- Los contratos y la nueva generación real se documentan en VALIDACION-0.21.9.md.

# Cambios 0.21.8 (2026-10-08)

- Contrato de listas compara la secuencia y sus límites en HTML, Word y Markdown; conserva listas anidadas. Una guarda común rechaza ordinales fuera del rango representable por navegador y Word en los cuatro formatos, sin alterar archivos previos.
- Índice PDF codifica las claves documentales, evita colisiones de secciones heredadas y exige referencias solo a los bloques emitidos. Las opciones CLI se aplican antes de la validación final.
- Referencias internas codificadas reservan sus IDs también en el editor. Fechas de seguimiento usan AAAA-MM-DD para mantener comparación cronológica y estados coherentes.
- Enteros no representables exactamente por el editor se rechazan con ruta de campo y recomendación de guardarlos como texto, sin redondear ni modificar la fuente.
- Creación desde diseños rechaza colisiones Unicode; declaraciones de anexos rechazan JSON ambiguo; bibliotecas exigen una versión entera válida.
- Tres diálogos de plantillas y notas usan modalidad nativa, foco inicial y restauración. Retiradas las trampas manuales de foco redundantes.
- Arranque con app.js ausente o JavaScript desactivado muestra un aviso operable y recarga nativa; el editor queda inerte hasta instalar sus eventos. Retirados estilos y markup animado de carga sin consumidor.
- Búsqueda del HTML portátil reconoce representaciones Unicode equivalentes sin retirar acentos. Documentación inglesa de actualización y validación puesta al día.
- Pruebas, exportaciones reales y límites documentados en VALIDACION-0.21.8.md.

# Cambios 0.21.7 (2026-10-08)

- Entradas nulas y títulos ausentes accesibles; idioma efectivo consistente; fragmentos codificados y resúmenes sin enlaces a detalles omitidos.
- Límites numéricos/contador seguros, importaciones Unicode y ZIP inválidos controlados, y arranque del editor con recuperación visible.
- Orden y límites de tablas comprobados en HTML, Word y Markdown; HTML portátil y tablas Word extensas mejorados.
- Retirados helpers sin consumidores; dependencia opcional PyMuPDF corregida a 1.26.7.
- Pruebas, exportaciones reales y límites documentados en VALIDACION-0.21.7.md.

# Cambios 0.21.6 (2026-10-08)

- Valida el espacio efectivo de anclas antes de exportar, incluidos controles portátiles y secciones automáticas, conservando identidades y claves personalizadas legítimas.
- Conserva todos los activos sin UID en el inventario, evita vínculos implícitos al último activo y admite títulos nulos en proyección sin inventar un título ni modificar la fuente.
- Corrige el falso rechazo de código PDF envuelto físicamente y detecta líneas reordenadas o repeticiones ausentes; mantiene explícitos los límites de extracción textual y revisión manual.
- HTML portátil con palabras completas en columnas comparativas intermedias, nota en main, versión visible de exportación y márgenes de impresión A4; el contenido histórico del ejemplo Banco Lumbre se conserva.
- Copia de CVSS espera confirmación de portapapeles, informa fallos y conserva nombre accesible estable.
- 1.200 pruebas Python, npm 12, DOM/API 29 y Chromium 48/72/24/58 aprobados. Nuevo informe Cooperativa Faro exportado en cuatro formatos, revisado en PDF/Word/HTML. Alcance y límites en VALIDACION-0.21.6.md.

# Cambios 0.21.5 (2026-10-08)

- Fichas del HTML portátil con columna de etiquetas acotada y alineación superior en escritorio; lectura apilada en móvil, conservando filas, encabezados y contenido.
- Tablas comparativas con anchura suficiente para leer los datos, región de desplazamiento local accesible por teclado y comportamiento de impresión independiente.
- Barra de filtros con geometría reservada antes del primer pintado y controles disponibles después de instalar eventos; arranque mínimo y script de lectura autorizados por sus hashes CSP.
- Fuente opcional en HTML portátil para evitar su intercambio tardío. Sin cambios de esquema, del motor PDF ni de los PDF históricos.
- Títulos móviles más contenidos para mantener palabras largas completas a 320 px, sin alterar escritorio ni impresión.
- Contratos de navegador y contenido para ES/EN y disposiciones por secciones/heredada. Resultados y límites en VALIDACION-0.21.5.md.

# Cambios 0.21.4 (2026-10-08)

- Severidad contrastada con vectores CVSS 3.1 y 4.0 cuando la puntuación escalar está ausente, nula o vacía, sin modificar ni completar datos del informe.
- Un tema explícitamente nulo se rechaza en la validación final; el editor conserva su normalización compatible al tema serio.
- Retiradas dos expresiones regulares sin uso y corregidas las descripciones de compatibilidad CVSS.
- 62 contratos nuevos de validación y exportación, con evidencia antes/después. Resultados y límites en VALIDACION-0.21.4.md.

# Cambios 0.21.3 (2026-10-08)

- HTML portátil sin desbordamiento en 320/360 px; reapertura del mismo fragmento con filtros activos y separación de anclas según la altura real de la barra.
- Exportaciones conservan imágenes WebP y enlazadas, referencias literales y vectores CVSS con puntuación ausente/null/vacía/cero. El inspector compara las referencias y la huella exacta de la conversión Word; mantiene las guardas de contenido y asociaciones.
- Importación JSON validada sobre copia antes de modificar el editor, con protección de cambios concurrentes y del proyecto elegido. La incorporación conserva las identidades del modelo para que Deshacer siga operativo.
- Diálogos nativos con foco, teclado y errores contextualizados; nombres de controles, semántica de listas, contraste observado, Ctrl+K móvil y referencias ARIA de exportación corregidos.
- Biblioteca sanea formas Markdown y rutas privadas sin alterar código literal ni citas bibliográficas. Las variables se vuelven a comprobar después de rellenarse.
- Respaldo conserva recuperación heredada y sus recursos sin escribir en el origen; creación y respaldo rechazan colisiones Unicode. Restauración completada con fallo posterior de limpieza devuelve éxito con aviso y conserva un reintento seguro.
- Excepciones de constructores YAML inválidos normalizadas como entrada 422, sin estado parcial.
- 196 casos Python nuevos; suite final completa: 1.050 aprobados sin omisiones. Editor: 72 comprobaciones en Chromium real; npm: 12; DOM/API: 29. Las suites previas de navegador aprueban 48 y 24 comprobaciones. Revisión visual de DOCX con LibreOfficeDev y PDF sintéticos. Nuevas guardas incorporadas al workflow Chromium.
- Auditoría y alcance en AUDITORIA-0.21.3.md y VALIDACION-0.21.3.md; guía de actualización con el caso de `.bak` omitido por exportadores anteriores. Word nativo, Firefox local y lector de pantalla siguen sin ejecutar en esta ronda.

# Cambios 0.21.2 (2026-10-05)

- RG-L01: IDs persistentes al eliminar, reordenar y duplicar fichas, contador de asignación sin reutilización y bloqueo de referencias internas huérfanas. Markdown incluye anclas explícitas; Word y Markdown enlazan también desde el resumen.
- RG-L02: contrato v3 con portada, metadatos tipados, tablas nativas y destinos de enlaces comparados con la copia pública de origen. CVSS escalar, incluido cero, se publica de forma explícita en Markdown.
- RG-L03: huella de cada imagen pública, pie, contexto y posición respecto de los comandos. Se detecta también el traslado de una evidencia entre pasos sin comandos. Recursos con espacios y corchetes se resuelven correctamente.
- RG-L04: el verificador excluye HTML estáticamente oculto mediante atributos o reglas CSS soportadas. Todos los formatos declaran revisión visual requerida. La interfaz muestra las nuevas comprobaciones y sus límites.
- RG-L05: metadatos iniciales de Word como párrafos nativos con continuidad de paginación. En el motor disponible, los 24 hallazgos y dos máquinas conservan su título con el comienzo del contenido; los cuatro casos huérfanos de la auditoría ya no se reproducen.
- Texto contextual ES/EN para CVSS/CWE opcionales sin registrar.
- 67 pruebas Python nuevas; suite completa: 854 aprobadas. 12 pruebas JS, 29 comprobaciones DOM/Flask y 26 comprobaciones en Chromium. Ocho mutaciones rechazadas. Informe Grupo Ladera repetido: PDF de 78 páginas y DOCX renderizado de 65 páginas. Word nativo, LibreOffice estable y Firefox siguen pendientes en este ciclo. Detalles en VALIDACION-0.21.2.md.

# Cambios 0.21.1 (2026-10-05)

- Contrato de contenido por hallazgo: párrafos completos con repeticiones y código literal. Mutaciones de contenido, espacios y ubicación provocan rechazo en HTML, Markdown y Word. PDF declara sus límites de extracción y revisión manual.
- Corregidos el recorte de espacios y líneas vacías de comandos y la expansión de tabulaciones dentro de bloques Markdown. Se conserva la protección contra HTML activo.
- Corregida la omisión del nombre genérico del equipo en Word y Markdown de informes antiguos sin evaluador.
- Inventario de datos privados, descarga y eliminación protegida de borradores, y limpieza transaccional de historial, anexos retirados y respaldo YAML anterior. La limpieza es explícita y conserva los datos actuales.
- Anexos obligatorios bloquean la entrega cuando faltan, están excluidos o no conservan su hash. Análisis orientativo de patrones y metadatos sin divulgar secretos ni modificar el anexo.
- Tamaños pequeños expresados en bytes, errores de anexos dentro del diálogo y limpieza del error al corregir el campo.
- Pruebas reales de conflictos entre pestañas, ENOSPC, EACCES, terminación del proceso entre renombres y recuperación en el mismo origen. Respaldo restaurado en una instalación vacía.
- CI ampliada para Chromium, Firefox y Windows; script de Word nativo disponible. Las ejecuciones remotas y Word de escritorio siguen pendientes. Resultados en VALIDACION-0.21.1.md.

# Cambios 0.21.0 (2026-10-05)

- Inventario explícito de anexos con SHA-256, límites de tamaño, revisión individual y copia seleccionada en `anexos/`. Los respaldos conservan anexos privados; las exportaciones individuales no los adjuntan.
- Registro visible y descargable de revisión, huellas y comprobaciones en cada exportación. Los resultados siguen ligados a su sesión local.
- Registro único de formatos para CLI, API, cola e interfaz. Comparación de títulos, comandos, filas de tablas y orden de listas con la copia de publicación.
- Inspección adicional de enlaces, integridad e imágenes publicadas en Word; retención del bloque introductorio del hallazgo con su contenido.
- Espaciado cómodo o compacto del informe, separado de la densidad del editor. Filtros de tipo, valoración pendiente, limpieza y estado vacío en HTML.
- Búsqueda de pasos y comandos en hallazgos y máquinas. Severidad pendiente explícita en selector, inicio y tablero; los hallazgos nuevos no reciben severidad por defecto.
- Corregida una referencia de índice no definido en Inicio para borradores sin ID.
- Instalador pip del entorno virtual actualizado antes de instalar dependencias. Comprobación final de paquetes sin avisos conocidos en las bases consultadas; no equivale a ausencia de vulnerabilidades.
- Pruebas reales en Chromium, matriz Chromium/Firefox en CI, ejemplo ficticio complejo y corpus de carga. Control manual de Microsoft Word sobre copias, con revisión de campos y exportación nativa.
- 34 pruebas Python nuevas. 739 casos Python distintos aprobados en la suite completa y la comprobación adicional del instalador; 49 comprobaciones reales de navegador. Firefox local bloqueado por EPERM y Microsoft Word nativo sin ejecutar. Detalles en VALIDACION-0.21.0.md.

# Cambios 0.20.2 (2026-10-05)

- La descarga individual de HTML deja de tratarse como ZIP. La cola y la entrega conjunta comparten el selector de inspección por formato. El inspector HTML comprueba recursos incorporados y destinos internos.
- Las etiquetas de Markdown se separan del contenido para conservar tablas, código y listas al comienzo de campos, pasos y resúmenes.
- Word conserva el orden de párrafos, código y sublistas, sus sangrías y los espacios entre estilos en línea.
- Los enlaces Markdown a hallazgos y secciones se convierten en enlaces internos de Word a marcadores estables. Los enlaces web siguen siendo externos.
- La exportación HTML por terminal valida el proyecto antes de publicar, igual que los otros formatos; un error no sobrescribe un destino existente.
- 27 pruebas nuevas; suite completa de 705 aprobadas. Dos simulaciones y verificación de PDF, DOCX, Markdown y HTML. Límites y resultados en VALIDACION-0.20.2.md. Sin migración de esquema.

# Cambios 0.20.1 (2026-10-05)

- Los hallazgos sin severidad permanecen en el resumen PDF, HTML, Word y Markdown, con etiqueta pendiente ES/EN. El conteo de máquinas se mantiene separado y no se fabrican puntuaciones.
- Los puntos del índice PDF se alinean con su entrada, incluidos los títulos que requieren varias líneas.
- Las tablas Markdown y estructuradas reparten columnas por contenido. PDF/HTML y Word comparten el criterio y las proporciones específicas de las tablas de activos, cobertura y retest.
- Los bloques Markdown usan el mismo estilo de bloque que los comandos, sin heredar cajas de código en línea. Los bloques cortos se mantienen juntos; las etiquetas breves en negrita acompañan a su bloque.
- Índice Word nativo con enlaces, marcadores y campos actualizables. El resultado inicial conserva títulos y no inventa números de página; F9 actualiza los campos en el editor.
- Pruebas de regresión y ejemplo ficticio de hallazgos pendientes. Alcance de la validación en VALIDACION-0.20.1.md.

# Cambios 0.20.0 (2026-10-04)

- Navegación Trabajar, Revisar, Entregar y Biblioteca; cabecera móvil compacta y preferencias agrupadas.
- Borradores recuperables, descarga de emergencia y resolución explícita de conflictos con validación estructural.
- Proyección pública común, imágenes sin metadatos, originales privados conservados y comparación compartible separada de la interna.
- Inspector de texto, recursos y huellas; patrones de secretos, excepciones registradas y censuras literales.
- Informe HTML autónomo con búsqueda, severidad, vista ejecutiva e impresión; lectura completa sin JavaScript.
- Corregidos vínculos rotos de capturas, selección CSV, huella original del importador, etiquetas Markdown y estados al duplicar/retest.
- Instrucciones inglesas de entrega y biblioteca ES/EN conservada. Calibri/Carlito y las mascotas no cambian.
- Lanzador de instalación/diagnóstico y documentación ES/EN. Evidencias antiguas separadas del paquete principal.
- Alcance, límites y ejecuciones documentados en VALIDACION-0.20.0.md.

# Cambios 0.18.0 (2026-10-04)

- Inicio contextual, retorno al último hallazgo y posición, y lista de actividad reciente.
- Navegación por trabajo, revisión y herramientas, densidad y concentración; autoría en «Acerca de».
- Símbolo vectorial compacto con Prometeo y Evaristo; ilustración original conservada.
- Editor por apartados con cabecera contextual; vista HTML sincronizada, ancho ajustable y revisión visible.
- Vista propia de Hallazgos, filtros y vistas guardadas. Corregido «Ver todos los hallazgos», que llevaba a la configuración del informe.
- Deshacer por operación para eliminaciones y reordenaciones, sin revertir texto editado después.
- Búsqueda de acciones con Ctrl+K y navegación de resultados por teclado.
- CSV/Burp en Archivo, Columnas y Revisión; protección frente a respuestas de archivos anteriores.
- Exportaciones en panel no modal con estado persistente, cancelación y restauración del foco.
- Verificación técnica separada de remediación/retest y revisión de importación; estados antiguos conservados.
- Bandeja privada con notas, comandos, HTTP e imágenes, original/SHA-256, vínculo explícito y respaldo.
- Traducciones de controles nuevos, barra Markdown y ubicaciones de búsqueda; idiomas del informe y de la interfaz independientes.
- Diseños, biblioteca bilingüe, logos de plataformas y tipografías de informes conservados.
- Regresiones y alcance documentados en VERIFICACION-0.18.0.md.

# Cambios 0.17.0 (2026-10-04)

- Versión canónica en `version.py`, compartida por empaquetado Python, API, dashboard y entregas.
- Corregido el manifiesto de entrega que todavía anunciaba 0.15.1.
- Estados de guardado, hora real, error persistente y reintento; la exportación no sobrescribe el estado de guardado.
- Cola de procesos con revisión inmutable, etapas reales, cancelación activa/en espera, limpieza y caducidad.
- CSV y Burp XML con vista previa, mapeo, procedencia, límites, deduplicación y revisión previa a entrega.
- Comparación visual de texto y evidencia histórica, con HTML autónomo imprimible.
- Conservados diseños, tipografías, logos y biblioteca bilingüe.
- Automatización Windows y script de Microsoft Word incluidos; ejecución nativa pendiente.
- Resultados y evidencia reproducible en `VERIFICACION-0.17.0.md`.

# Cambios 0.16.0 (2026-10-03)

- Dashboard con estado real del proyecto, accesos a hallazgos y preparación de entrega.
- Cabecera reorganizada, navegación móvil, temas claro y oscuro y foco visible.
- Emblema de Prometeo y Evaristo sobre una consola; wordmark HTML sin cortes.
- Separados el idioma de interfaz y el del documento: cambiar ES/EN no altera el informe.
- 150 nuevas vistas inglesas, además de las 150 españolas. Editor personal con campos ES/EN.
- Respaldo integral de proyectos, originales, historial y ambas bibliotecas personales.
- Restauración solo en instalación vacía, límites acumulados, hashes y recuperación ante interrupciones.
- 574 pruebas Python, 29 comprobaciones del nuevo DOM, cinco de guardado y 50 en Chromium.
- Muestras inglesas OSCP y CPTS en PDF/Word; fuentes del informe y motores conservados.

# Cambios 0.15.1 (2026-10-03)

- Logos de OffSec y Hack The Box en los 22 perfiles y sus dos variantes, en PDF,
  Word y vistas previas. Recursos incluidos, con procedencia y hashes.
- Selección clara u oscura según el fondo, sin sustituir los logos de autor y cliente.
- Corregida la vista previa de plantillas personales con estructura mínima.
- Conservada la variante Sobria al duplicar, guardar y crear desde una plantilla personal.
- Valores inválidos para un diseño general devuelven 422 sin modificar el proyecto.
- Galería y 50 pares de muestras regenerados; pruebas y alcance en VERIFICACION-0.15.1.md.

# Cambios 0.15.0 (2026-10-03)

- Biblioteca con 14 perfiles OffSec y ocho HTB, seis diseños generales conservados y referencias históricas separadas.
- Cinco composiciones nuevas con título central y datos en el tercio inferior, variantes Marca y Sobria, Calibri/Carlito y código monoespaciado.
- Galería con 150 vistas reales de portada, resumen y página técnica, búsqueda y filtros.
- Creación ES/EN con guías TODO; aplicar apariencia conserva el contenido existente.
- Plantillas personales con edición de colores, composición y estructura. Cada proyecto conserva su propia copia de la apariencia.
- Orientación de entrega con fuente y fecha de consulta; Markdown propuesto para CWEE y limitación de cifrado explícita.
- Escrituras atómicas, revisión de biblioteca y proyecto, entradas acotadas y comprobación de que la biblioteca escrita pueda volver a abrirse.
- Muestras PDF y Word, regresión de Nimbus, pruebas de navegador y limitaciones registradas en VERIFICACION-0.15.0.md.

# Cambios 0.14.0 (2026-10-03)

- Demo Nimbus editable con copias independientes, guía breve y diagnóstico real de instalación.
- Editor visual para plantillas reutilizables: vulnerabilidades, máquinas, fases,
  pasos, variables, CVSS, ayuda de redacción, vista previa y JSON opcional.
- Preparar entrega desde una instantánea guardada: formatos seleccionables,
  avisos explícitos, comprobación de recursos y ZIP con hashes de las salidas.
- Diseños propios Ejecutivo y Laboratorio en PDF y Word; seis temas revisados.
- Catorce presets revisados en ES/EN, con guías TODO y sin afirmaciones de
  compromisos no realizados. Se corrige la especialidad de CWEE y CWPE.
- Portadas con ilustraciones más compactas, encabezados Word alineados y código
  monoespaciado con DejaVu Sans Mono. No se añade un prompt ficticio a los comandos.
- Contraste corregido en etiquetas de máquinas y avisos del editor en modo claro.
- Regresiones, muestras nativas y límites documentados en VERIFICACION-0.14.0.md.

# Cambios 0.13.5 (2026-10-03)

- Registro de activación y recuperación de procesos interrumpidos, con copias
  conservadas cuando falla también la reversión.
- Reescritura de destinos Markdown comprobada por el parser, sin alterar código,
  etiquetas ni texto; trabajo de análisis acotado y rechazo sin cambios si no
  puede demostrar la conservación del contenido.
- Revisión de imágenes consistente con el parser y separación de campos de
  texto, comandos y recursos; rechazo final de imágenes no locales.
- Validación de campos legacy de exportación; valores nulos y numéricos admitidos
  conservados en Word y Markdown.
- Bloqueo del idioma durante navegación pendiente.
- Escape de texto plano y tablas Markdown; celdas estructuradas Word literales
  para conservar todos sus valores.
- Evidencia, regresiones y límites en VERIFICACION-0.13.5.md.

# 0.13.2 - 2026-10-02

## 0.13.4 - 2026-10-03

Reauditoría sobre el ZIP 0.13.3 entregado. Guardado y evidencias se preparan como
un estado completo; errores controlados conservan el proyecto anterior. El escritor
comprueba los límites de su lector. Eliminación/restauración bloquean la navegación
hasta completar la operación. Markdown conserva código literal y normaliza también
imágenes por referencia. DOCX admite vector CVSS nulo y se rechazan caracteres no
compatibles. YAML limita nodos durante su composición. Se corrige una expectativa
antigua que aprobaba modificar código literal al censurar una imagen.

293 tests Python, 5 JavaScript, 75 comprobaciones Chromium. Nimbus conserva sus
673 fragmentos, 19 imágenes y composición. Alcance y limitaciones en VERIFICACION-0.13.4.md.

## 0.13.3 - 2026-10-03

Auditoría adversa sobre 0.13.2. Censura por recurso canónico, respaldo e historial
con imágenes externas a img/, lectura acotada de JSON/YAML con rechazo de claves
duplicadas y datos no finitos, fechas ISO, alias con identidades independientes,
decodificación única de URLs y cabeceras inválidas rechazadas sin errores 500.
Arranque con Waitress local de un proceso. Dependencias de producción fijadas y
consultadas contra avisos conocidos. Véase VERIFICACION-0.13.3.md.


- Auditoría del informe Nimbus completo usando las salidas nativas y el editor real.
- Markdown conserva los metadatos y las imágenes de portada en las dos ramas de exportación.
- Escape de pies de figura, rutas locales codificadas y empaquetado de nombres reales.
- Cercas de código más largas que las presentes en el comando original.
- Modo `vuln` implícito coherente en numeración de figuras y plantilla PDF clásica.
- Word: gráfico de severidad ES/EN, tamaño legible y fuente DejaVu Sans incluida con licencia.
- Word: unión de etiquetas de lista y plazos de remediación con su contenido.
- Diez regresiones adicionales. Registro y evidencia en `VERIFICACION-0.13.2.md`.
- Se conservan los cálculos CVSS y el formato de los proyectos.

# 0.13.1 - 2026-10-02

- Protege las entregas con escritura atómica y copia consistente de YAML e imágenes durante la exportación web.
- Corrige la sustitución de referencias de evidencia para no modificar nombres que solo comparten un prefijo.
- Rechaza exportaciones finales de hallazgos sin ID o con versión CVSS incompatible con su vector; conserva los borradores.
- Da formato a tablas Markdown y columnas de activos, cobertura y retest; mantiene encabezados y evidencias de retest juntos cuando caben.
- Corrige el contraste de etiquetas de severidad en los cuatro temas y los colores de texto del gráfico.
- Añade soporte WebP/rotación EXIF a Word, logos e ilustración de portada, OSID/correo y figuras ajustadas al área imprimible.
- Adapta el cuerpo del tema HTB en Word a papel blanco; conserva su portada oscura.
- Escapa cadenas de cabeceras CSS de forma segura y evita entidades HTML visibles.
- Conserva el nombre report-gen en una línea, mejora controles estrechos y foco; completa etiquetas ES/EN.
- Descarta vistas previas antiguas, libera sus URLs y permite reintentar la sesión tras un error transitorio.
- Corrige pies de evidencia con escapes Markdown y estilos de títulos/pies de Word.
- Incluye regresiones Python/DOM, comprobación reproducible en Chromium y registro de auditoría.

---

# 0.13.0 — 2026-09-08

- Añade historial completo de proyectos con objetos deduplicados, etapas con nombre, comparación por identidad y restauración de archivos con rollback.
- Añade respaldos portables con manifiesto de integridad y un importador acotado que verifica rutas, tipos de imagen, enlaces, duplicados y tamaños.
- Añade revisión de entrega, activos, cobertura, limitaciones, seguimiento de correcciones y registros de retest.
- Añade galería de evidencias compartidas, originales separados y edición que aplana anotaciones/censura en PNG sin metadatos.
- Añade biblioteca local versionada con etiquetas, variables, saneado de campos del proyecto, revisión de texto e importación/exportación.
- Introduce identificadores permanentes y migración compatible de proyectos antiguos.
- Integra activos, evidencias, cobertura y retest en PDF, DOCX y Markdown; incluye sus secciones en el índice PDF.
- Conserva la paginación continua y la protección de tablas de hallazgos. Evita párrafos vacíos añadidos entre pasos en Word.
- Incluye guía, respaldo de demostración ficticio y pruebas de los nuevos recorridos con el editor y la API reales.

---

# Changelog

Formato basado en Keep a Changelog. Versionado semantico aproximado.

## [0.12.1] - 2026-09-08

### Paginación
- Se elimina el salto obligatorio entre hallazgos en todos los temas PDF y en
  ambas rutas del exportador DOCX.
- El encabezado PDF permanece unido a su tabla principal; las tablas del hallazgo
  no se fragmentan para aprovechar un espacio insuficiente al final de página.
- Los procedimientos largos conservan el flujo entre páginas.
- Los marcadores del índice acompañan al encabezado al cambiar de página.
- Word utiliza filas indivisibles y encadena los párrafos de cada tabla; los
  encabezados permanecen con su contenido siguiente.
- WeasyPrint comprueba sus fragmentos de página antes de escribir. Chromium
  dispone de una comprobación mediante marcadores temporales en un PDF previo;
  esos marcadores se retiran de la salida final.
- Un PDF con una tabla demasiado alta se rechaza con un mensaje accionable. La
  API devuelve el motivo sin cambiar el proyecto guardado.
- Se añaden pruebas de paginación real, movimiento de tablas, índice, DOCX y API.
  Detalles y límites en VERIFICACION-0.12.1.md.

## [0.12.0] - 2026-09-08

### Corregido
- RG-01: los guardados capturan proyecto, contenido y revisión; cambiar de
  proyecto espera el guardado pendiente y se cancela si falla.
- RG-02: los errores HTTP conservan el estado pendiente; las respuestas antiguas
  no marcan como guardadas ediciones más recientes.
- RG-03: saneado compartido de Markdown y atributos; payloads HTML visibles como
  texto, sin ejecución. Las bases de imágenes se aíslan por petición.
- RG-04: validación de rango y finitud del score, coherencia con vector y severidad,
  parser CVSS 3.1 estricto y visualización correcta de la puntuación numérica 0.
- RG-05: validación de estructuras anidadas antes de escribir, y reparación del
  fallo de traducción del validador. La exportación final exige datos válidos.
- RG-06: Word conserva las imágenes Markdown, enlaces, listas, tablas y bloques
  de código con saltos e indentación.
- RG-07: Markdown se entrega en un ZIP con sus imágenes relativas.
- RG-08: validación de Host y Origin, CSRF de sesión, tipo JSON obligatorio,
  política CSP y restricción de recursos externos y rutas en los renderizadores.
- RG-09: colores explícitos y etiquetas completas en el gráfico SVG del PDF.

### Añadido
- Escritura atómica del YAML, copia de una versión anterior y botón Restaurar.
- ETag/If-Match para detectar conflictos entre pestañas; subida de imágenes con
  nombres únicos y sin sobrescribir evidencias existentes.
- Exportación desde instantáneas temporales sin modificar el proyecto guardado.
- Pruebas de regresión, guardado JavaScript y editor con API HTTP real y jsdom.
- Dependencias de desarrollo JavaScript y CI actualizado; guía de migración y
  registro de verificación. Nuevas dependencias runtime: nh3 y lxml.

### Compatibilidad
- Markdown CLI/UI ahora produce `.zip`; `to_markdown` sigue devolviendo texto.
- Los clientes API deben enviar cookie de sesión, token CSRF y revisión ETag.
- El YAML sigue siendo compatible; datos inválidos antes tolerados pueden bloquear
  una exportación hasta que se corrijan. Las imágenes se limitan al proyecto.
- `tests/run_stdlib.py` requiere pytest y delega la ejecución de la suite.

### Funciones ya presentes en el ZIP recibido


### Anadido
- Biblioteca de hallazgos reutilizables (guardar un hallazgo como plantilla e
  insertarlo despues; se guarda en el navegador).
- Importar / exportar hallazgos en JSON.
- Mensajes de validacion bilingues (ES/EN) segun el idioma de la interfaz.

## [0.11.0] - 2026-09-02

### Anadido
- Dashboard de hallazgos (seccion Hallazgos): tabla Severidad/Hallazgo/CWE/CVSS con
  resumen y barra de distribucion, conmutador de orden Severidad/Manual (en Manual se
  reordena arrastrando), filtro por severidad y marcador de hallazgos incompletos
  (sin CVSS/CWE).
- Panel de resultados CVSS en el editor: tarjeta de puntuacion, tarjeta MacroVector y
  metricas en lenguaje claro (3.1 y 4.0, bilingue).
- Tema claro/oscuro de la interfaz (persistente), con boton en la barra superior.
- Indicador de carga en la vista previa (patita giratoria + "Actualizando...") mientras
  se re-renderiza o se cambia el idioma del informe.
- Toasts de feedback (proyecto creado, exportado, copiado) y estado de exportacion
  (el boton muestra "Generando..." y se deshabilita hasta terminar).
- Validacion visible: boton que revisa el informe y muestra un panel de avisos; incluye
  ahora hallazgos sin CVSS o sin titulo, y el badge indica errores/avisos.
- Atajos de teclado: Ctrl/Cmd+K (buscador), Ctrl/Cmd+S (guardar), Esc (cerrar).

### Corregido
- El primer hallazgo ya no se separa del titulo de su seccion en el PDF (evita la
  pagina casi en blanco con solo el titulo): solo saltan de pagina los hallazgos que
  siguen a otro.
- La barra de la vista previa (Vivo/PDF) ahora se adapta al tema claro/oscuro.

## [0.10.0] - 2026-09-01

### Anadido
- Plantillas por tipo de informe con diseno propio: OffSec (estilo OSCP, claro/azul
  acero, sans) y HTB (oscuro de punta a punta, verde-lima). Cada plantilla fija su
  tema automaticamente al crear el proyecto.
- Familia HTB con selector en dos pasos: al elegir "HTB (certificacion)" aparece un
  2o selector con 8 certificaciones (CPTS, CWES, CAPE, COAE, CWEE, CWPE, CJCA, CDSA),
  cada una con su estructura de secciones e indice propios y texto base bilingue.
- Portadas con imagenes: logo propio y logo del cliente (HTB) e imagen representativa
  del caso (OffSec), subibles desde el editor; disposicion vertical por tema.
- Campos OSID y Email en la portada (para informes de examen), en tabla ordenada.
- Secciones genericas con titulo propio (apendices nombrados A-G, Technical Analysis,
  Exam Objectives, Phase 1/2, etc.), editables en el webapp y con entrada propia en
  el indice.
- Splash de arranque minimalista (patita + report-gen, fade-out al cargar).

### Corregido
- Coherencia editor <-> informe: el listado de secciones a la izquierda coincide
  exactamente con el indice del informe en cada plantilla (se elimino el forzado de
  secciones "obligatorias"; ahora son solo recomendadas y el preset manda).
- El selector de plantillas del modal se repuebla al abrir, respetando el idioma de
  la interfaz (antes quedaba en espanol al cambiar a ingles).
- El validador ya no marca como error las secciones genericas (con titulo propio).
- i18n completado en el modo maquina, el modo secciones y las nuevas etiquetas.

### Nota de marca
Los nombres "estilo OSCP/HTB" y las certificaciones (CPTS, CWES, etc.) son
descriptivos. report-gen no esta afiliado ni respaldado por OffSec ni Hack The Box y
no reproduce sus plantillas oficiales: los disenos, la estructura y el texto son
propios; los logos los aporta el usuario.


### Anadido
- Plantillas (presets) de secciones al crear proyecto: Pentest cliente, Examen de
  certificacion (estilo OSCP), certificacion HTB (estilo CPTS: pentest de red con
  narrativa de ataque, y estilo CWES: explotacion web), y CTF/Maquina. Encienden las
  secciones tipicas y rellenan texto base bilingue (ES/EN). Nombres descriptivos, sin
  logos y con nota de no-afiliacion a OffSec / Hack The Box.

## [0.9.0] - 2026-09-01
### Anadido
- Buscador global: campo en la barra superior que busca una palabra en TODO el
  proyecto (portada, contactos, alcance, secciones, hallazgos, maquinas y pasos),
  muestra resultados con contexto resaltado y navega al sitio con un clic.
- Calculadora CVSS: barra "Pegar vector" — pega un vector completo (3.1 o 4.0, con o
  sin prefijo, admite espacios) y calcula al instante; detecta la version y cambia
  sola. Sigue disponible el modo casilla por casilla.
- Duplicar hallazgo (copia todo el contenido con nuevo id).
- Renombrar proyecto (boton junto al selector); el nombre del selector se sincroniza
  solo al editar el titulo o el tema/idioma.
- Auto-foco en el titulo al crear un hallazgo; Enter para crear en el dialogo de
  nuevo proyecto; aviso al salir con cambios sin guardar.
- Editor: contactos y alcance se editan desde su propia seccion (antes solo en
  «Informe»); los datos siguen en meta.contacts/meta.scope.
- Vista previa colapsable (boton mostrar/ocultar; recuerda la preferencia).
- Eliminar proyecto (boton + endpoint DELETE seguro por ruta).
- Autodeteccion de CWE: al escribir un numero o nombre, autocompletado que filtra
  segun escribes y muestra el nombre (endpoint /api/cwe). Trae ~124 CWE comunes;
  `webapp/data/build_cwe.py` genera el catalogo COMPLETO de MITRE (requiere red).
- i18n del sitio: toggle ES/EN que traduce toda la interfaz (topbar, sidebar,
  editores, modales) y pone el informe en ese idioma; recuerda la preferencia.
### Cambiado
- UI del sitio: paleta oscura neutra con acento teal, tipografia sans, tamanos
  mayores; botones de anadir hallazgo agrupados.
### Corregido
- PDF con acentos en Windows (HTML temporal de Chromium en UTF-8); backend PDF
  cae a Chromium si WeasyPrint no carga (GTK ausente en Windows).
- Empaquetado: pyproject declara paquetes/modulos (arreglo de `pip install -e .`).
- Figuras Markdown: el borde se ajusta a la imagen (no una caja ancha).
- Preview a altura completa (regla #pdfPreview) y sin perder el scroll al hacer zoom.
- Eliminados presets, designs obsoletos y las referencias OSCP/CAPE del README que
  ya no formaban parte del flujo actual (quedan menciones conceptuales legitimas en
  ejemplos/plantillas).

## [0.8.0] - 2026-08-31

CVSS 4.0 de extremo a extremo (motor, JS, API y UI) validado contra la
implementacion de referencia de FIRST/Red Hat.

### Anadido
- CVSS 4.0 como motor separado de la 3.1 en el paquete `cvss/`: `v31.py` intacto,
  `v40.py` nuevo, interfaz comun en `__init__.py` con `score(vector)` que despacha
  estrictamente por version (`CVSS:3.1/`, `CVSS:4.0/`; cualquier otra -> ValueError).
- Parser 4.0 normativo estricto: prefijo de version, metricas y valores permitidos,
  orden canonico de FIRST, sin duplicados, sin segmentos vacios (barra final/doble
  barra) y todas las Base presentes. No normaliza entradas mal formadas: las rechaza.
- `effective_metrics()` (defaults 4.0 sin mutar el parsed: original -> parsed ->
  effective), `eq1..eq6`, `macrovector()` e interpolacion `_score()` portada de la
  implementacion de referencia FIRST/Red Hat (misma aritmetica; sin "mejorarla",
  el objetivo es same input -> same output).
- Artefactos de referencia congelados: tabla oficial MacroVector->score
  (`v40_lookup.py`, 270 entradas) y `MAX_COMPOSED`/`MAX_SEVERITY`/`EPSILON`
  (`v40_constants.py`).
- `cvss.score('CVSS:4.0/...')` devuelve `{score, severity, vector, macrovector}`.

### Verificacion
- Integridad estructural: los EQ derivan exactamente el espacio de los 270
  MacroVectors oficiales (y los 5 pares validos EQ3/EQ6).
- Corpus de referencia externo congelado (`tests/reference/first_v40_vectors.json`,
  367 vectores: 270 MacroVectors, 101 scores distintos 0.0-10.0, anclas y el caso
  de redondeo del issue como regresion permanente).
- Sin divergencias (0) entre `v40` y una copia VERBATIM del algoritmo de la
  implementacion de referencia FIRST/Red Hat (ramas exactas, incl. EQ3/EQ6 sin
  colapsar) sobre 19.815 vectores aleatorios + el corpus; anclas publicadas por
  FIRST (10.0, el 8.7 interpolado del issue, 0.0) correctas.
- Tests en dos clases: `test_cvss_v40.py` (propiedades propias: parser, EQ,
  invariantes) y `test_cvss_v40_reference.py` (vs el oraculo de referencia).

- Port JavaScript de CVSS 4.0 (`webapp/static/cvss40.js`): port mecanico del Python
  validado (no un tercer algoritmo); las tablas JS se generan desde los datos de
  Python, asi que solo el algoritmo es manual. Lo usa la calculadora web sin duplicar
  el algoritmo en app.js.
- Paridad Python<->JS: 0 divergencias en SCORE **y** en MACROVECTOR sobre el corpus
  congelado (367) + ~20k deterministas (20.087 en total, 270/270 MacroVectors);
  test separado de effective_metrics/defaults (E:X->A, CR/IR/AR:X->H, modificadas
  X->base, MSI:S/MSA:S -> EQ4). Anclas de FIRST en JS: 10.0 / 8.7 / 0.0.

- Integracion web 4.0 (sin tocar los motores CVSS):
  - `/api/cvss`, politica de despacho documentada: si `version` esta presente se
    respeta estrictamente; si falta, compat legacy (prefijo CVSS:4.0/ -> 4.0; el
    resto o `metrics` -> 3.1); si `version` y el prefijo del vector se contradicen
    -> 400. En modo 3.1 un vector debe empezar por CVSS:3.1/ (o enviar `metrics`);
    en 4.0 debe empezar por CVSS:4.0/. Version no soportada / vector invalido -> 400,
    nunca cross-version silencioso ni score parcial. 3.1 conserva su comportamiento;
    4.0 devuelve {score, severity, vector, macrovector}.
  - UI: selector CVSS 3.1 / 4.0 en la calculadora del hallazgo; al cambiar de version
    se reconstruyen las metricas y se descarta el estado incompatible. La logica 4.0
    NO se duplica en app.js: la UI llama a `cvss40.js` (buildVector canonico + score).
    Alcance: calculadora CVSS 4.0 Base (11 metricas); las opcionales (Threat,
    Environmental, Supplemental) toman sus defaults, el MOTOR ya las soporta, y su
    edicion desde la UI queda para v0.9+.
  - Verificado con Playwright: UI 4.0 == backend Python (10.0/000100 y 8.7/001200
    interpolado), vector en orden canonico, sin errores de consola, y 4.0 -> 3.1
    resetea el estado.
- Tests nuevos: API (`test_api_cvss.py`: 3.1 preservado, 4.0 shape, version/vector
  invalidos 4xx, sin cross-version) y `test_ui_loads_cvss40.py` (index.html carga
  cvss40.js antes de app.js; app.js no duplica tablas 4.0). Skips de Node ahora via
  `pytest.skip`/runner (PASS vs SKIPPED); CI instala Node. Suite: 86 tests.

### Referencia (procedencia)
- Implementacion y datos: `RedHatProductSecurity/cvss`, release v3.6 (commit
  2f149099257ae06b98cef252efc440bddafe61e5, 2026-08-04), ficheros `cvss/cvss4.py` y `cvss/constants4.py` (este ultimo
  contiene MAX_COMPOSED, MAX_SEVERITY, EPSILON y CVSS_LOOKUP_GLOBAL).
- Origen de la tabla lookup: FIRSTdotorg/cvss-v4-calculator (`cvss_lookup.js`),
  vendorizada por FIRST/Red Hat.

- Corroboracion del changelog upstream: v3.2 "Fixes CVSS v4.0 rounding issues /
  Makes rounding match official Javascript implementation" respalda la aritmetica
  de redondeo portada (EPSILON + Decimal half-up).

### Sello de referencia (cerrado)
- Python vs implementacion de referencia = 100%: ejecutado el paquete upstream
  `cvss==3.6` de PyPI (RedHatProductSecurity/cvss), SIN modificar, en subproceso
  aislado, sobre 20.087 vectores (corpus congelado + ~20k deterministas, 270/270
  MacroVectors): 0 errores de parseo, 0 divergencias de score. Script reproducible:
  `seal_upstream.py`.
- Procedencia resuelta: el sello confirma que los artefactos vendorizados
  (`v40_lookup.py`, `v40_constants.py`) corresponden a la referencia v3.6
  (commit 2f149099257ae06b98cef252efc440bddafe61e5); se elimina el residuo
  "master@2026-08-31".
- [hecho] Paridad Python<->JS 4.0 (score + macrovector) sin tocar la UI.
- [hecho] Integracion web: /api/cvss por version + selector UI 3.1/4.0 (UI == backend).
- [hecho] Regresion completa (incl. 3.1): 86/86.
- Nota (compat parser): el `parse_vector` de upstream acepta metricas fuera de orden;
  el nuestro es estricto. El sello compara solo vectores canonicos (validos para ambos).

Nota: `cvss/v40.py` permanece congelado (misma aritmetica que la referencia; solo
se modificaria ante una divergencia contra upstream, que no la hay).

### Seguridad / robustez (auditoria exhaustiva)
- Slug de proyecto capado a 80 chars: un slug enorme ya no crashea con OSError (500).
- Endpoints endurecidos: un body JSON no-dict (lista/string/null) devuelve 400 en vez
  de 500 en /api/cvss, /api/validate, /api/md, crear y guardar proyecto; el PUT con
  body invalido ya NO sobrescribe el proyecto con vacio.
- /api/cvss coacciona el vector a string (antes un vector numerico crasheaba).
- proj_dir con defensa en profundidad: el path resuelto debe quedar dentro de projects/.
- i18n completado: el modo maquina (fases, pasos, evidencia), el boton de preview y el
  titulo "Contenido" ahora traducen al ingles. CSS muerto eliminado.

### Corregido
- Export DOCX/MD de maquinas: exportar un informe con un hallazgo `machine` (sin
  `severity`) ya no crashea (`KeyError: 'severity'`); en el resumen aparece como
  "Maquina" sin score, con sus fases/pasos/comandos y tabla de flags.
- Resumen de hallazgos: las maquinas ya no cuentan como severidad "Media" ni entran
  al grafico; aparecen listadas como "Maquina" y se mencionan aparte en el intro.
- Log de PDF: se silencia el bloque de aviso de WeasyPrint; una sola linea limpia
  cuando cae a Chromium.
- UX: selector de color para el acento, selector de fecha nativo, tooltips en cada
  metrica CVSS, confirmacion al borrar un hallazgo, boton "copiar vector", y
  placeholders con ejemplos en portada y hallazgos (IP, SO, puertos, ruta de ataque), pista en el modo
  maquina (el comando va en el paso, no en el nombre de fase) y estado vacio que guia
  a "Nuevo proyecto".
- Validador: los vectores CVSS 4.0 validos ya no se marcan como "formato
  inesperado" (la regex solo conocia 3.1); ahora el 4.0 se valida con el motor CVSS.
- Informe: la etiqueta CVSS ahora refleja la version real del vector (CVSS 4.0 /
  CVSS 3.1) en PDF/HTML, DOCX y Markdown; antes rotulaba siempre "CVSS 3.1".
- Preview no ejecuta scripts del contenido (iframe sandbox) y el HTML crudo de la
  prosa se muestra como texto literal (payloads visibles, sin self-XSS).
- Textareas de contenido auto-expandibles (crecen con el texto, sin scroll).
- Portabilidad Windows: el HTML temporal que se pasa a Chromium para el PDF se
  escribe ahora en UTF-8 (`NamedTemporaryFile(..., encoding="utf-8")`); en Windows
  el default es cp1252 y las tildes/acentos salian como "?" en el PDF, aunque el
  preview HTML se veia bien. Con test de regresion independiente de plataforma.
- Portabilidad Windows: los tests que leen/escriben archivos (`test_ui_loads_cvss40`,
  `test_cvss_v40_js_parity`) ahora fijan `encoding="utf-8"`; en Windows el default
  es cp1252 y fallaba al leer `app.js` (iconos multibyte de la barra del editor). El
  codigo del producto ya usaba utf-8 explicito en todas sus lecturas/escrituras.
- Empaquetado: `pyproject.toml` declara explicitamente los paquetes (`cvss`,
  `exporters`) y modulos (`engine`, `export`, `sections`, `validate`, `wizard`),
  arreglando el fallo de setuptools "Multiple top-level packages ... flat-layout"
  que rompia `pip install -e .` (y por tanto el CI). `license` pasa a string SPDX
  ("MIT"), sin la deprecacion de la tabla.
- Backend PDF mas robusto: si `import weasyprint` falla por CUALQUIER motivo
  (p. ej. `OSError` por faltar GTK en Windows), el backend `auto` cae a Chromium
  en vez de crashear; con `--backend weasyprint` el mensaje indica la causa.
- Typo en el docstring de `export.py` ("e re-exporta" -> "y reexporta").

## [0.7.0] - 2026-08-31
### Cambiado
- Refactor puramente estructural de la exportacion: `export.py` (950 lineas) se
  divide en el paquete `exporters/` (`common.py`, `markdown.py`, `docx.py`,
  `pdf.py`) y queda como fachada de compatibilidad de ~50 lineas. Sin cambios de
  comportamiento: salida MD identica byte a byte y DOCX identico (mismo contenido
  y estilos); los 40 tests siguen verdes antes y despues. Los consumidores
  (`webapp`, tests, CLI) no cambian: siguen usando `import export`.
- Micro-limpieza en la subida de imagenes: la imagen se abre una sola vez con
  context manager (`with Image.open(...)`).

## [0.6.0] - 2026-08-31
### Anadido
- Suite de tests con pytest (`tests/`): CVSS (vectores oficiales + paridad
  Python/JS sobre 2592 combinaciones), motor, secciones, export PDF/DOCX/MD,
  seguridad (traversal, saneo, subida de imagenes) y validacion. Runner de
  stdlib (`tests/run_stdlib.py`) para entornos sin pytest.
- Validacion de engagement sin dependencias (`validate.py`): IDs duplicados,
  severidad invalida, hallazgo machine sin host, CVSS mal formado, severidad
  incoherente con CVSS y secciones inexistentes. Integrada en el motor (avisos
  al generar) y en la app (`POST /api/validate`).
- Scaffolding de proyecto: `pyproject.toml` (config de pytest y Ruff),
  `.gitignore`, `LICENSE` (MIT), este `CHANGELOG.md` y CI en GitHub Actions.

### Corregido
- Contradiccion en el README: el DOCX se genera con python-docx puro (sin
  LibreOffice), no convirtiendo HTML.
- README: aclarado que `tests/run_stdlib.py` evita pytest pero no las
  dependencias runtime (los tests importan engine, Flask, Markdown, etc.).
- Validacion: los fallos internos del validador ya no se silencian; se muestran
  como aviso, para no dar por validado un engagement cuando el validador fallo.
- Subida de imagenes endurecida: validacion real con Pillow (`Image.verify()`,
  no solo magic bytes), formato restringido a png/jpg/gif/webp, extension
  derivada del formato REAL detectado (el nombre no decide el tipo servido),
  limite HTTP (`MAX_CONTENT_LENGTH`) y lectura acotada en memoria.
- Marcadores de numeracion a dos pasadas endurecidos (fuera de flujo dentro de
  contenedor posicionado) para paginacion identica entre pasadas en informes
  largos.

## [0.5.0] - 2026-08-31
### Anadido
- Constructor modular de secciones con catalogo canonico unificado y editor
  Markdown por seccion estilo SysReptor (barra, Write/Preview, imagenes).
- Secciones obligatorias bloqueables; toggle de idioma ES/EN a un clic.
- Export DOCX y Markdown conscientes de las secciones activas.

### Corregido
- Auditoria de seguridad: crash por tema invalido, inyeccion de ruta via
  meta.theme, subida de imagen con nombre malicioso.

## [0.4.0] - 2026-08-31
### Anadido
- App web local estilo SysReptor: editor de hallazgos, calculadora CVSS 3.1,
  catalogos OWASP (web y LLM), preview en vivo y export multiformato.
- DOCX reescrito en python-docx puro (identico al PDF, sin LibreOffice).

## [0.1.0 - 0.3.0] - 2026-08-31
### Anadido
- Motor de render (WeasyPrint/Chromium), temas, i18n ES/EN, numeracion de TOC a
  dos pasadas, hallazgos vuln/machine, asistente CLI y export inicial.
