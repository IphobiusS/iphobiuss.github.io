"""Configuracion de pytest: agrega la raiz del repo y webapp/ al path."""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
for p in (ROOT, ROOT / "webapp"):
    if str(p) not in sys.path:
        sys.path.insert(0, str(p))
